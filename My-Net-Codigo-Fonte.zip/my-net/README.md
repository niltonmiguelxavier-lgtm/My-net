# My Net

Marketplace para descoberta de vendedores de serviços de internet em Moçambique.

## Stack
- Next.js 15 + React + TypeScript
- Supabase Auth e PostgreSQL
- Preparado para deploy na Vercel

## Executar no Replit
1. Crie um projecto Node.js no Replit e carregue este ZIP ou importe o repositório.
2. No Shell execute `npm install`.
3. Copie `.env.example` para `.env.local`.
4. Crie um projecto Supabase e configure `NEXT_PUBLIC_SUPABASE_URL` e `NEXT_PUBLIC_SUPABASE_ANON_KEY` em Secrets.
5. No Supabase SQL Editor, execute todo o ficheiro `supabase/schema.sql`.
6. Execute `npm run dev`.

## Publicar na Vercel
1. Envie o projecto para um repositório GitHub.
2. Importe o repositório na Vercel.
3. Configure as mesmas variáveis públicas do Supabase em Project Settings > Environment Variables.
4. Faça deploy.

## Planos comerciais iniciais
- Gratuito: 0 MT/mês, até 2 anúncios activos.
- Profissional: 500 MT/mês, até 10 anúncios activos.
- Premium: 1.200 MT/mês, anúncios ilimitados sujeitos a regras de utilização.

Os preços e limites estão centralizados em `lib/plans.ts` e também existem na tabela `plans` da base de dados. Mantenha os dois sincronizados quando alterar os valores.

## Pagamentos
A aplicação **não processa pagamentos reais nesta versão**. O esquema permite registar pedidos e confirmação administrativa. Para activar M-Pesa/e-Mola:
- Obter credenciais comerciais oficiais e documentação do fornecedor.
- Implementar endpoint server-side com validação de assinatura/estado.
- Confirmar transacções no servidor, nunca apenas no browser.
- Não guardar PINs, OTPs ou palavras-passe de carteiras móveis.
- Activar a subscrição apenas após confirmação verificável.

## Segurança e estado do projecto
Este ZIP é uma base inicial funcional de interface e estrutura, não um marketplace de produção completo. Antes de lançar:
- Implementar autenticação/registo/login e fluxos de recuperação.
- Criar painel seguro de administração com atribuição de papéis controlada.
- Implementar aprovação administrativa que cria o registo do vendedor.
- Aplicar limites de anúncios e regras de subscrição no servidor/RLS.
- Criar upload privado e revisão de documentos de verificação.
- Implementar mensagens, favoritos, notificações e avaliações com regras anti-abuso.
- Rever políticas RLS e testar com contas cliente, vendedor e administrador.
- Configurar integração de pagamentos e termos/privacidade.

## Estrutura
- `app/`: páginas Next.js
- `lib/`: configuração Supabase e planos
- `supabase/schema.sql`: tabelas, enums, índices implícitos, triggers e RLS inicial
- `.env.example`: variáveis de ambiente de exemplo
