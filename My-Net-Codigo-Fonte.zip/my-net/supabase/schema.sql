-- MY NET: schema inicial Supabase/PostgreSQL
create extension if not exists pgcrypto;

create type public.app_role as enum ('customer','seller','admin','superadmin');
create type public.application_status as enum ('pending','approved','rejected');
create type public.subscription_status as enum ('pending','active','expired','cancelled','rejected');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  phone text,
  role public.app_role not null default 'customer',
  created_at timestamptz not null default now()
);

create table public.seller_applications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  business_name text not null,
  phone text not null,
  category text not null,
  province text not null,
  district text not null,
  plan_id text not null default 'free' check (plan_id in ('free','pro','premium')),
  status public.application_status not null default 'pending',
  admin_notes text,
  created_at timestamptz not null default now()
);

create table public.sellers (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null unique references auth.users(id) on delete cascade,
  business_name text not null,
  phone text not null,
  category text not null,
  province text not null,
  district text not null,
  verified boolean not null default false,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table public.plans (
  id text primary key check (id in ('free','pro','premium')),
  name text not null,
  price_mzn integer not null check (price_mzn >= 0),
  listing_limit integer,
  active boolean not null default true
);
insert into public.plans(id,name,price_mzn,listing_limit) values
 ('free','Gratuito',0,2),('pro','Profissional',500,10),('premium','Premium',1200,null)
on conflict (id) do nothing;

create table public.subscriptions (
  id uuid primary key default gen_random_uuid(),
  seller_id uuid not null references public.sellers(id) on delete cascade,
  plan_id text not null references public.plans(id),
  status public.subscription_status not null default 'pending',
  payment_method text check (payment_method in ('mpesa','emola','bank_transfer','manual')),
  payment_reference text,
  amount_mzn integer not null check (amount_mzn >= 0),
  starts_at timestamptz,
  ends_at timestamptz,
  confirmed_by uuid references auth.users(id),
  created_at timestamptz not null default now()
);

create table public.listings (
  id uuid primary key default gen_random_uuid(),
  seller_id uuid not null references public.sellers(id) on delete cascade,
  title text not null,
  category text not null,
  description text,
  price_mzn integer not null check (price_mzn >= 0),
  speed_label text,
  validity text,
  province text not null,
  district text not null,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table public.reviews (
  id uuid primary key default gen_random_uuid(),
  seller_id uuid not null references public.sellers(id) on delete cascade,
  customer_id uuid not null references auth.users(id) on delete cascade,
  rating integer not null check (rating between 1 and 5),
  comment text,
  created_at timestamptz not null default now(),
  unique(seller_id,customer_id)
);

create table public.reports (
  id uuid primary key default gen_random_uuid(),
  reporter_id uuid not null references auth.users(id) on delete cascade,
  seller_id uuid references public.sellers(id) on delete set null,
  listing_id uuid references public.listings(id) on delete set null,
  reason text not null,
  details text,
  status text not null default 'open' check (status in ('open','reviewing','resolved','dismissed')),
  created_at timestamptz not null default now()
);

create or replace function public.is_admin()
returns boolean language sql stable security definer set search_path=public
as $$ select exists(select 1 from public.profiles where id=auth.uid() and role in ('admin','superadmin')); $$;

alter table public.profiles enable row level security;
alter table public.seller_applications enable row level security;
alter table public.sellers enable row level security;
alter table public.plans enable row level security;
alter table public.subscriptions enable row level security;
alter table public.listings enable row level security;
alter table public.reviews enable row level security;
alter table public.reports enable row level security;

create policy "profiles read own or admin" on public.profiles for select using (id=auth.uid() or public.is_admin());
create policy "profiles update own" on public.profiles for update using (id=auth.uid()) with check (id=auth.uid());
create policy "applications insert own" on public.seller_applications for insert with check (user_id=auth.uid());
create policy "applications read own or admin" on public.seller_applications for select using (user_id=auth.uid() or public.is_admin());
create policy "applications admin update" on public.seller_applications for update using (public.is_admin()) with check (public.is_admin());
create policy "public read approved active sellers" on public.sellers for select using (verified=true and active=true);
create policy "seller read own" on public.sellers for select using (user_id=auth.uid());
create policy "seller update own basic" on public.sellers for update using (user_id=auth.uid()) with check (user_id=auth.uid());
create policy "plans public read" on public.plans for select using (active=true);
create policy "subscriptions own read" on public.subscriptions for select using (exists(select 1 from public.sellers s where s.id=seller_id and s.user_id=auth.uid()) or public.is_admin());
create policy "subscriptions own request" on public.subscriptions for insert with check (exists(select 1 from public.sellers s where s.id=seller_id and s.user_id=auth.uid()) and status='pending');
create policy "subscription admin update" on public.subscriptions for update using (public.is_admin()) with check (public.is_admin());
create policy "public read active listings" on public.listings for select using (active=true);
create policy "seller manage own listings" on public.listings for all using (exists(select 1 from public.sellers s where s.id=seller_id and s.user_id=auth.uid())) with check (exists(select 1 from public.sellers s where s.id=seller_id and s.user_id=auth.uid()));
create policy "reviews public read" on public.reviews for select using (true);
create policy "customer create review" on public.reviews for insert with check (customer_id=auth.uid());
create policy "reports own create" on public.reports for insert with check (reporter_id=auth.uid());
create policy "reports own or admin read" on public.reports for select using (reporter_id=auth.uid() or public.is_admin());

-- Criar automaticamente um perfil básico após registo Auth.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path=public
as $$ begin
 insert into public.profiles(id,full_name) values(new.id, coalesce(new.raw_user_meta_data->>'full_name',''));
 return new;
end; $$;
create trigger on_auth_user_created after insert on auth.users
for each row execute procedure public.handle_new_user();

-- IMPORTANTE: atribuir admin/superadmin manualmente através do painel SQL seguro.
-- Nunca permitir que o próprio utilizador altere o campo role.
