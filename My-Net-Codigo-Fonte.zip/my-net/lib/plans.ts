export type PlanId = "free" | "pro" | "premium";

export const plans = [
  {
    id: "free" as const,
    name: "Gratuito",
    priceMzn: 0,
    period: "mês",
    listingLimit: 2,
    features: ["Perfil público de vendedor", "Até 2 anúncios activos", "Receber contactos de clientes", "Sem destaque nas pesquisas"]
  },
  {
    id: "pro" as const,
    name: "Profissional",
    priceMzn: 500,
    period: "mês",
    listingLimit: 10,
    features: ["Até 10 anúncios activos", "Maior visibilidade nas pesquisas", "Estatísticas de visualizações", "Gestão de ofertas"]
  },
  {
    id: "premium" as const,
    name: "Premium",
    priceMzn: 1200,
    period: "mês",
    listingLimit: null,
    features: ["Anúncios activos ilimitados*", "Destaque na plataforma", "Estatísticas avançadas", "Suporte prioritário"]
  }
];

export function formatMzn(value: number) {
  return new Intl.NumberFormat("pt-MZ", { maximumFractionDigits: 0 }).format(value) + " MT";
}
