import Link from "next/link";
import { plans, formatMzn } from "@/lib/plans";

const categories = [
  ["📱","Dados móveis","Pacotes de internet para telemóveis"],
  ["📡","Wi-Fi residencial","Internet para casa e pequenos negócios"],
  ["🔌","Fibra óptica","Conexões de alta velocidade"],
  ["🛰️","Internet via satélite","Conectividade em zonas remotas"],
  ["📶","Internet wireless","Soluções sem fios"],
  ["🏪","Revendedores","Distribuidores e vendedores independentes"]
];

export default function Home() {
  return <>
    <header className="topbar"><div className="container nav">
      <Link href="/" className="brand"><span className="brandmark">⌁</span>My Net</Link>
      <nav className="navlinks"><a href="#categorias">Categorias</a><a href="#como-funciona">Como funciona</a><Link href="/planos">Planos para vendedores</Link></nav>
      <Link className="btn" href="/registar-vendedor">Quero vender</Link>
    </div></header>
    <main>
      <section className="hero"><div className="container">
        <span className="pill">MARKETPLACE DE INTERNET EM MOÇAMBIQUE</span>
        <h1>A internet certa está mais perto.</h1>
        <p>Encontre vendedores de internet, compare ofertas e escolha a conexão ideal para a sua casa, negócio ou dia a dia.</p>
        <form className="searchbox" action="/vendedores">
          <input name="q" placeholder="O que procura? Ex.: Wi-Fi, fibra, dados móveis" aria-label="Pesquisar vendedores"/>
          <input name="location" placeholder="Cidade ou bairro" aria-label="Localização"/>
          <button className="btn">Encontrar vendedores</button>
        </form>
      </div></section>
      <section className="section" id="categorias"><div className="container">
        <div className="sectionhead"><div><h2>Explore por categoria</h2><p className="muted">Diferentes soluções de conectividade num só lugar.</p></div></div>
        <div className="grid">{categories.map(([icon,name,desc])=><article className="card category" key={name}><div className="categoryicon">{icon}</div><div><h3>{name}</h3><p className="muted small">{desc}</p></div></article>)}</div>
      </div></section>
      <section className="section" id="como-funciona" style={{background:"#edf3fb"}}><div className="container">
        <div className="sectionhead"><div><h2>Simples, transparente e seguro</h2><p className="muted">O My Net ajuda a aproximar clientes e vendedores.</p></div></div>
        <div className="grid">{[["01","Pesquise","Indique o tipo de internet e a sua localização."],["02","Compare","Consulte pacotes, preços, condições e avaliações."],["03","Contacte","Fale directamente com o vendedor e confirme os detalhes."]].map(([n,t,d])=><article className="card" key={n}><div className="categoryicon">{n}</div><h3 style={{marginTop:16}}>{t}</h3><p className="muted">{d}</p></article>)}</div>
      </div></section>
      <section className="section"><div className="container center"><h2>É vendedor de internet?</h2><p className="muted">Crie o seu perfil e apresente as suas ofertas a novos clientes.</p><Link className="btn" href="/planos">Conhecer planos de vendedor</Link></div></section>
    </main>
    <footer className="footer"><div className="container"><strong>My Net</strong><p className="small">Encontre vendedores. Compare ofertas. Conecte-se.</p><p className="small">Os selos de verificação são atribuídos apenas após análise administrativa. O My Net não é, por si só, um operador de telecomunicações.</p></div></footer>
  </>;
}
