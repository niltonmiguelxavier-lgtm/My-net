"use client";
import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { Suspense, useState } from "react";
import { createClient } from "@/lib/supabase";
function Form(){
 const params=useSearchParams(); const [msg,setMsg]=useState(""); const [busy,setBusy]=useState(false);
 async function submit(e:React.FormEvent<HTMLFormElement>){
  e.preventDefault(); setBusy(true); setMsg("");
  const fd=new FormData(e.currentTarget);
  try{
   const supabase=createClient();
   const {data,error}=await supabase.auth.getUser();
   if(error||!data.user){setMsg("Para concluir o pedido, primeiro crie uma conta ou entre na sua conta. A autenticação será activada quando configurar o Supabase.");setBusy(false);return;}
   const {error:insertError}=await supabase.from("seller_applications").insert({
    user_id:data.user.id, business_name:fd.get("business_name"), phone:fd.get("phone"),
    category:fd.get("category"), province:fd.get("province"), district:fd.get("district"),
    plan_id:fd.get("plan_id"), status:"pending"
   });
   if(insertError) throw insertError;
   setMsg("Candidatura enviada. Aguarde a análise administrativa.");
  }catch(err){setMsg(err instanceof Error?err.message:"Não foi possível enviar. Verifique a configuração do Supabase.");}
  setBusy(false);
 }
 return <form className="form" onSubmit={submit}><Link href="/" className="muted small">← Voltar ao início</Link><h1>Registo de vendedor</h1><p className="muted">Apresente o seu negócio para análise e verificação.</p>
 <div className="notice">O envio da candidatura não significa aprovação automática. A equipa My Net irá analisar os dados.</div>
 <label className="field">Nome comercial<input name="business_name" required placeholder="Nome da empresa ou negócio"/></label>
 <div className="two"><label className="field">Telefone<input name="phone" required placeholder="+258 8x xxx xxxx"/></label><label className="field">Plano<select name="plan_id" defaultValue={params.get("plano")||"free"}><option value="free">Gratuito</option><option value="pro">Profissional — 500 MT/mês</option><option value="premium">Premium — 1.200 MT/mês</option></select></label></div>
 <label className="field">Categoria principal<select name="category" required><option value="">Seleccione</option><option>Dados móveis</option><option>Wi-Fi residencial</option><option>Fibra óptica</option><option>Internet via satélite</option><option>Internet wireless</option><option>Revendedor</option><option>Outro</option></select></label>
 <div className="two"><label className="field">Província<input name="province" required placeholder="Ex.: Tete"/></label><label className="field">Distrito / cidade<input name="district" required placeholder="Ex.: Moatize"/></label></div>
 <button className="btn" disabled={busy} style={{width:"100%"}}>{busy?"A enviar...":"Enviar candidatura"}</button>{msg&&<p className="notice" style={{marginTop:15}}>{msg}</p>}
 </form>
}
export default function SellerRegister(){return <Suspense fallback={<p className="center">A carregar...</p>}><Form/></Suspense>}
