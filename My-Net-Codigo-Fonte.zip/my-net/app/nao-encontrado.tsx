export default function NotFound(){return <main className="section center"><h1>Página não encontrada</h1><a href="/" className="btn">Voltar ao início</a></main>}
