import Link from "next/link";
import { plans, formatMzn } from "@/lib/plans";
export default function PlansPage(){
 return <><header className="topbar"><div className="container nav"><Link href="/" className="brand"><span className="brandmark">⌁</span>My Net</Link><Link href="/registar-vendedor" className="btn">Registar como vendedor</Link></div></header>
 <main className="section"><div className="container"><div className="center"><h1>Planos para vendedores</h1><p className="muted">Escolha o plano que acompanha o crescimento do seu negócio.</p></div>
 <div className="plans" style={{marginTop:32}}>{plans.map(p=><article className={`plan ${p.id==="pro"?"featured":""}`} key={p.id}>{p.id==="pro"&&<span className="pill">MAIS ESCOLHIDO</span>}<h2>{p.name}</h2><div className="planprice">{formatMzn(p.priceMzn)}<span className="muted small"> / mês</span></div><ul>{p.features.map(f=><li key={f}>{f}</li>)}</ul><Link className={`btn ${p.id==="pro"?"":"secondary"}`} style={{width:"100%"}} href={`/registar-vendedor?plano=${p.id}`}>Escolher {p.name}</Link></article>)}</div>
 <p className="muted small" style={{marginTop:20}}>* Uso ilimitado sujeito à política de utilização aceitável e às regras de publicação. Os preços são valores iniciais configuráveis pelo administrador.</p>
 <div className="notice" style={{marginTop:20}}>Os pagamentos por M-Pesa e e-Mola dependem de integração e credenciais comerciais oficiais. Até essa configuração, os pedidos de subscrição ficam pendentes e só são activados após confirmação administrativa. Nunca envie PIN ou palavra-passe de carteira móvel.</div>
 </div></main></>;
}
