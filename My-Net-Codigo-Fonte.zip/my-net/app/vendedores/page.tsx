import Link from "next/link";
export default async function Sellers({searchParams}:{searchParams:Promise<{q?:string;location?:string}>}){
 const p=await searchParams;
 return <><header className="topbar"><div className="container nav"><Link href="/" className="brand"><span className="brandmark">⌁</span>My Net</Link><Link href="/registar-vendedor" className="btn">Quero vender</Link></div></header>
 <main className="section"><div className="container"><h1>Encontrar vendedores</h1><p className="muted">Resultados para: {p.q||"todos os serviços"} {p.location?`em ${p.location}`:""}</p>
 <div className="notice">A listagem pública será alimentada por vendedores aprovados na base de dados. Não existem vendedores reais publicados nesta versão inicial.</div>
 <div className="card center" style={{marginTop:20}}><h3>Ainda não há vendedores para apresentar</h3><p className="muted">Volte mais tarde ou convide um vendedor de confiança a registar-se.</p><Link href="/registar-vendedor" className="btn">Registar vendedor</Link></div>
 </div></main></>;
}
