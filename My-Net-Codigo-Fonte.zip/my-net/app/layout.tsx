import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = {
  title: "My Net — Encontre vendedores de internet",
  description: "Descubra, compare e contacte vendedores de serviços de internet verificados em Moçambique."
};
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="pt"><body>{children}</body></html>;
}
